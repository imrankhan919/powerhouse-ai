import React from "react";
import { Link } from "react-router-dom";

const PlanCard = () => {
  return (
    <div className="p-5 bg-blue-400">
      <h1 className="text-2xl font-semibold my-2">Weight Loss Plan</h1>
      <p className="text-sm text-gray-600 my-2">Date : 18-Jan-25</p>
      <Link to={"/plan/123"}>
        <button className="bg-black text-white w-1/2 py-1 mt-5 hover:bg-gray-500 duration-200">
          View
        </button>
      </Link>
    </div>
  );
};

export default PlanCard;
