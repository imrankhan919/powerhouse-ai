import React from "react";
import PlanCard from "../components/PlanCard";
import BackButton from "../components/BackButton";

const ViewPlans = () => {
  return (
    <div className="min-h-[90vh] p-10">
      <BackButton url={"/"} />
      <h1 className="text-center my-5 text-2xl font-bold">
        All Your Fitness Plans
      </h1>
      <div className="border p-5 rounded-md grid gap-4 grid-cols-1 md:grid-cols-3">
        <PlanCard />
        <PlanCard />
        <PlanCard />
      </div>
    </div>
  );
};

export default ViewPlans;
